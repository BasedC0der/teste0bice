<?php 
$bottoken= "7343417675:AAFgki0qTwT6c-KIa4dNmLoJT-WCfm9NGIM";
$chatids = array("922817542");
?>
