# Read the IPs from a text file (one IP per line)
with open('ips.txt', 'r') as file:
    ips = file.readlines()

# File where you want to append the IPs
file_path = 'C:/xampp/htdocs'

# Open the file and write the IPs
with open(file_path, 'a') as file:
    for ip in ips:
        file.write(f"deny from {ip.strip()}\n")